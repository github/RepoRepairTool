﻿
namespace JabbR.Services
{
    public interface ICryptoService
    {
        string CreateSalt();
    }
}