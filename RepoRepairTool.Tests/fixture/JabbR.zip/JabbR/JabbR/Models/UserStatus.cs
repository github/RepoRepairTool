﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JabbR.Models
{
    public enum UserStatus
    {
        Active,
        Inactive,
        Offline
    }
}