﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JabbR.Models
{
    public class ClientState
    {
        public string UserId { get; set; }
        public string ActiveRoom { get; set; }
    }
}