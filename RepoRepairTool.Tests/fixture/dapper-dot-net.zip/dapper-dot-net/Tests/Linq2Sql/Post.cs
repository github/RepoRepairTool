﻿
namespace SqlMapper.Linq2Sql
{
    public partial class Post
    {
        /*
        public int Bloat { get; set; }
        public int Bloat1 { get; set; }
        public int Bloat2 { get; set; }
        public int Bloat3 { get; set; }
        public int Bloat4 { get; set; }
        public int Bloat5 { get; set; }
        public int Bloat6 { get; set; }
        public int Bloat7 { get; set; }
        public int Bloat8 { get; set; }


        public int Bloat10 { get; set; }
        public int Bloat11 { get; set; }
        public int Bloat12 { get; set; }
        public int Bloat13 { get; set; }
        public int Bloat14 { get; set; }
        public int Bloat15 { get; set; }
        public int Bloat16 { get; set; }
        public int Bloat17 { get; set; }
        public int Bloat18 { get; set; }
        */
    }
}
